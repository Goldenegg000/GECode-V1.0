var commands = document.getElementById("code");var brocken = true;var errormassages = true;var veriables = {version: "GECode ver.1.0"}
function run(e) {errormassages = true;document.getElementById("code2").innerHTML = '@echo off <br>';document.getElementById("output").innerHTML = "";
var inputtext1 = document.getElementById("code").value.replaceAll("%VER%", veriables.version);
var i;commands = inputtext1.split('\n');document.getElementById("output").innerHTML = document.getElementById("output").innerHTML + "output:" + "<br>";
for (i = 0; i < commands.length; i++) {
var current = commands[i];current = current.trim();brocken = true;
if (current.startsWith("//") || current.length == 0) {
if (current.startsWith("//")) {document.getElementById("code2").innerHTML = document.getElementById("code2").innerHTML + "::" + current.substring(2) + "<br>";
}brocken = false;
} else {
if (current.substr(current.length - 1) == ";") {current = current.substr(0, current.length - 1);
if (current.startsWith("engine.error ")) {
if (current.substring(13) == "true") {errormassages = true;brocken = false;
}
if (current.substring(13) == "false") {errormassages = false;brocken = false;
}}
if (current.startsWith("popup ")) {alert(current.substring(6));document.getElementById("code2").innerHTML = document.getElementById("code2").innerHTML + "::CONVERTER: popups are not added yet." + "<br>";brocken = false;
}
if (current.startsWith("commandline.add ")) {document.getElementById("output").innerHTML = document.getElementById("output").innerHTML + "> " + current.substring(16) + "<br>";document.getElementById("code2").innerHTML = document.getElementById("code2").innerHTML + "echo " + current.substring(16) + "<br>";brocken = false;
}
if (current.startsWith("commandline.clear") && current.length == 17 ) {document.getElementById("output").innerHTML = "output:<br>";document.getElementById("code2").innerHTML = document.getElementById("code2").innerHTML + "cls<br>";brocken = false;
}}}
if (brocken && errormassages) {var iline = i + 1;document.getElementById("output").innerHTML = document.getElementById("output").innerHTML + "ERROR at line(" + iline + ') = "' + current + '"<br>';
}}document.getElementById("code2").innerHTML = document.getElementById("code2").innerHTML + "pause";
}
function reset() {document.getElementById('output').innerHTML = 'output:<br>';document.getElementById('code2').innerHTML = "click 'Run Code' to get a convertion.<br>";
}
function infos(x) {
if (x) {document.getElementById("window1").style.display = "none";document.getElementById("window2").style.display = "block";
} else {document.getElementById("window1").style.display = "block";document.getElementById("window2").style.display = "none";
}}